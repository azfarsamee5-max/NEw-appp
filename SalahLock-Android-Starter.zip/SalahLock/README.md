# Salah Lock (safe-focus starter)

A local-first Android starter built with Kotlin, Jetpack Compose Material 3, MVVM,
Room and WorkManager. Min SDK 26; target SDK 34.

## Build
1. Install Android Studio (current stable) and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Run the `app` configuration on an Android 8.0+ device or emulator.

The Adhan Java dependency is used for offline prayer calculations. The default
coordinates are Lahore (31.5204, 74.3587), Karachi calculation method and Hanafi
Asr. Verify local prayer times against a trusted local timetable before relying
on notifications; calculation conventions and high-latitude rules can differ.

## Permissions
- Location: optional; grant while using the app to replace the Lahore default
  with device coordinates. Manual city selection is the privacy-preserving option.
- Notifications: grant on Android 13+ if reminders are enabled.
- No overlay, Accessibility, Usage Access, Device Admin, or uninstall-blocking
  permissions are requested. The app must not interfere with emergency access.

## Current implementation
- Compose home checklist for five prayers, Quran and Hadith.
- Room daily completion records.
- Offline prayer calculation adapter.
- Material 3 green theme.
- Reader content placeholder and WorkManager reminder worker skeleton.

## Important remaining work
- Implement prayer-method/adjustment settings and GPS/manual city picker.
- Add an actual licensed Quran Arabic + Urdu + English dataset and licensed
  Hadith collection under `app/src/main/assets`; the bundled README describes
  the expected record shape. No religious text is fabricated in this starter.
- Implement reader navigation, bookmarks, screen-on/visible reading timer,
  daily goals, qaza and weekly streak queries.
- Add notification channel, reminder scheduling, exact-alarm UX only if the
  feature truly needs exact timing, and boot-safe rescheduling.
- Add Urdu translations and RTL layout testing.
- Add dark theme and accessibility testing.
- Add optional voluntary focus sessions using Android's user-controlled
  Digital Wellbeing/Focus features where available.

## Safety and platform notes
Android does not provide an ordinary app with a supported way to guarantee
blocking every other app. Overlay/Accessibility-based interception is fragile,
can disrupt assistive technology, and can interfere with emergency access.
This project deliberately does not implement a forced app lock, covert
foreground-app surveillance, camera verification, Device Admin anti-uninstall,
or a lock that the owner cannot exit.
