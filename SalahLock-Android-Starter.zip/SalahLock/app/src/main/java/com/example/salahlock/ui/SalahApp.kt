package com.example.salahlock.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val requiredTasks = listOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha", "Quran", "Hadith")

@Composable
fun SalahApp(vm: SalahViewModel) {
    val completed by vm.tasks.collectAsState()
    val done = completed.filter { it.completed }.map { it.task }.toSet()
    var selected by remember { mutableStateOf("Home") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Salah Lock") })
        },
        bottomBar = {
            NavigationBar {
                listOf("Home", "Reader", "Stats", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = selected == item,
                        onClick = { selected = item },
                        icon = { Text(item.take(1)) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        when (selected) {
            "Home" -> HomeScreen(vm, done, Modifier.padding(padding))
            "Reader" -> ReaderScreen(Modifier.padding(padding))
            "Stats" -> StatsScreen(done, Modifier.padding(padding))
            else -> SettingsScreen(Modifier.padding(padding))
        }
    }
}

@Composable
private fun HomeScreen(vm: SalahViewModel, done: Set<String>, modifier: Modifier = Modifier) {
    val next = vm.schedule.nextPrayer()
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Assalamu Alaikum", style = MaterialTheme.typography.headlineMedium)
            Text(LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM")))
            Spacer(Modifier.height(8.dp))
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("Next prayer", style = MaterialTheme.typography.titleMedium)
                    Text(next?.name ?: "All prayers for today", style = MaterialTheme.typography.headlineSmall)
                    Text(next?.time?.format(DateTimeFormatter.ofPattern("h:mm a")) ?: "MashaAllah")
                }
            }
            Text("Today's checklist", style = MaterialTheme.typography.titleLarge)
        }
        items(vm.schedule.slots) { slot ->
            TaskRow(slot.name, slot.time.format(DateTimeFormatter.ofPattern("h:mm a")), slot.name in done) {
                vm.markDone(slot.name)
            }
        }
        item {
            TaskRow("Quran", "Daily reading goal", "Quran" in done) { vm.markDone("Quran") }
            TaskRow("Hadith", "Daily reading goal", "Hadith" in done) { vm.markDone("Hadith") }
        }
    }
}

@Composable
private fun TaskRow(name: String, detail: String, checked: Boolean, onDone: () -> Unit) {
    ElevatedCard {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium)
                Text(detail, style = MaterialTheme.typography.bodyMedium)
            }
            if (checked) Text("Done ✓", color = MaterialTheme.colorScheme.primary)
            else TextButton(onClick = onDone) { Text("I completed it") }
        }
    }
}

@Composable
private fun ReaderScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Offline Reader", style = MaterialTheme.typography.headlineMedium)
        Text("Reader content is a starter placeholder. Add licensed Quran Arabic/Urdu/English text and Hadith records to app/src/main/assets.")
        Text("A reading session should only count while this screen is visible and the device screen is on.")
    }
}

@Composable
private fun StatsScreen(done: Set<String>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Today's progress", style = MaterialTheme.typography.headlineMedium)
        Text("${done.size} of 7 tasks completed")
        LinearProgressIndicator(progress = { done.size / 7f }, modifier = Modifier.fillMaxWidth())
        requiredTasks.forEach { Text("${if (it in done) "✓" else "○"}  $it") }
        Text("Weekly streak and qaza summaries can be built from the dated Room records.")
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text("Default city: Lahore, Pakistan")
        Text("Calculation: Karachi • Asr: Hanafi")
        Text("Focus mode is voluntary. Emergency access and uninstall remain available.")
        Text("Add controls here for calculation method, Asr school, per-prayer adjustments, language, theme and whitelist.")
    }
}
