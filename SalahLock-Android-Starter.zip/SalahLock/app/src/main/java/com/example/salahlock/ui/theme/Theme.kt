package com.example.salahlock.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF176B45)
private val LightGreen = Color(0xFFE8F3EC)

@Composable
fun SalahTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Color(0xFF54866B),
            background = Color(0xFFF8FBF8),
            surface = Color.White,
            surfaceVariant = LightGreen
        ),
        content = content
    )
}
