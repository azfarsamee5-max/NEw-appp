package com.example.salahlock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salahlock.ui.SalahApp
import com.example.salahlock.ui.SalahViewModel
import com.example.salahlock.ui.theme.SalahTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = SalahDatabase.getInstance(applicationContext)
        setContent {
            SalahTheme {
                val vm: SalahViewModel = viewModel(
                    factory = SalahViewModel.factory(database.taskDao())
                )
                SalahApp(vm)
            }
        }
    }
}
