package com.example.salahlock.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_tasks", primaryKeys = ["date", "task"])
data class DailyTask(
    val date: String,
    val task: String,
    val completed: Boolean = false,
    val completedAtMillis: Long? = null
)
