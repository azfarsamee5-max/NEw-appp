package com.example.salahlock.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Placeholder worker for gentle local reminders.
 * Schedule it from onboarding after notification permission is granted.
 */
class DailyNudgeWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // TODO: Create a notification channel and post a non-intrusive reminder.
        return Result.success()
    }
}
