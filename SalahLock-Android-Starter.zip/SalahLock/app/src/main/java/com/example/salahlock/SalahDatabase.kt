package com.example.salahlock

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.salahlock.data.DailyTask
import com.example.salahlock.data.TaskDao

@Database(entities = [DailyTask::class], version = 1, exportSchema = false)
abstract class SalahDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile private var INSTANCE: SalahDatabase? = null
        fun getInstance(context: Context): SalahDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SalahDatabase::class.java,
                    "salah-lock.db"
                ).build().also { INSTANCE = it }
            }
    }
}
