package com.example.salahlock.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.salahlock.data.DailyTask
import com.example.salahlock.data.TaskDao
import com.example.salahlock.domain.PrayerCalculator
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class SalahViewModel(private val dao: TaskDao) : ViewModel() {
    private val today = LocalDate.now().toString()
    val tasks = dao.observeDay(today).stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )
    val schedule = PrayerCalculator.calculate()

    fun markDone(task: String) = viewModelScope.launch {
        dao.upsert(DailyTask(today, task, true, System.currentTimeMillis()))
    }

    companion object {
        fun factory(dao: TaskDao) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                SalahViewModel(dao) as T
        }
    }
}
