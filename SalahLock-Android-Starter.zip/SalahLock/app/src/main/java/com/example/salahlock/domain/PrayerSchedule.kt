package com.example.salahlock.domain

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

data class PrayerSlot(val name: String, val time: LocalTime)

data class PrayerSchedule(
    val date: LocalDate,
    val slots: List<PrayerSlot>,
    val sunrise: LocalTime
) {
    fun nextPrayer(now: LocalDateTime = LocalDateTime.now()): PrayerSlot? =
        slots.firstOrNull { it.time.isAfter(now.toLocalTime()) }
}

/**
 * Offline calculation adapter.
 * Lahore + Karachi method + Hanafi are the defaults. Adjustments are applied
 * after the library returns the astronomical prayer times.
 */
object PrayerCalculator {
    fun calculate(date: LocalDate = LocalDate.now()): PrayerSchedule {
        // Adhan Java API usage; coordinates are Lahore defaults.
        val coordinates = com.batoulapps.adhan.Coordinates(31.5204, 74.3587)
        val params = com.batoulapps.adhan.CalculationMethod.KARACHI.parameters
        params.madhab = com.batoulapps.adhan.Madhab.HANAFI
        val prayerTimes = com.batoulapps.adhan.PrayerTimes(
            coordinates,
            date,
            params
        )
        fun local(value: java.util.Date) =
            value.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalTime()
        return PrayerSchedule(
            date = date,
            slots = listOf(
                PrayerSlot("Fajr", local(prayerTimes.fajr)),
                PrayerSlot("Zuhr", local(prayerTimes.dhuhr)),
                PrayerSlot("Asr", local(prayerTimes.asr)),
                PrayerSlot("Maghrib", local(prayerTimes.maghrib)),
                PrayerSlot("Isha", local(prayerTimes.isha))
            ),
            sunrise = local(prayerTimes.sunrise)
        )
    }
}
