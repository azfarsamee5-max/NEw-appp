package com.example.salahlock.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM daily_tasks WHERE date = :date")
    fun observeDay(date: String): Flow<List<DailyTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: DailyTask)

    @Query("SELECT * FROM daily_tasks WHERE date >= :fromDate ORDER BY date DESC")
    fun observeSince(fromDate: String): Flow<List<DailyTask>>
}
