Add properly licensed offline content here.
Suggested schema:
[
  {
    "surah": 1,
    "ayah": 1,
    "arabic": "...",
    "translation_ur": "...",
    "translation_en": "..."
  }
]
Do not redistribute a translation or Hadith edition unless its license permits bundling.
The current UI intentionally contains no fabricated Quran or Hadith text.
